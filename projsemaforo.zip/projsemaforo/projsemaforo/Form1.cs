﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projsemaforo
{
    public partial class Form1 : Form
    {
        private Semaforo semaforo;
        public Form1()
        {
            InitializeComponent();
            semaforo = new Semaforo();
            atualizaInterface();
        }

        private void btnVm_Click(object sender, EventArgs e)
        {
            this.semaforo.setVermelho(int.Parse(txtRua.Text));
            atualizaInterface();
        }

        private void btnAm_Click(object sender, EventArgs e)
        {
            this.semaforo.setAmarelo(int.Parse(txtRua.Text));
            atualizaInterface();
        }

        private void btnVd_Click(object sender, EventArgs e)
        {
            this.semaforo.setVerde(int.Parse(txtRua.Text));
            atualizaInterface();
        }

        public void atualizaInterface()
        {
            lblR1.Text = this.semaforo.getEstado(1).ToString();
            lblR2.Text = this.semaforo.getEstado(2).ToString();

            picR1.Image = (this.semaforo.getEstado(1) == 1) ? projsemaforo.Properties.Resources.vd :
                          (this.semaforo.getEstado(1) == 2) ? projsemaforo.Properties.Resources.am :
                          projsemaforo.Properties.Resources.vm;

            picR2.Image = (this.semaforo.getEstado(2) == 1) ? projsemaforo.Properties.Resources.vd :
                          (this.semaforo.getEstado(2) == 2) ? projsemaforo.Properties.Resources.am :
                          projsemaforo.Properties.Resources.vm;
        }
    }
}
