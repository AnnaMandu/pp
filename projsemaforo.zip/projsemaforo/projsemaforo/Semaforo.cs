﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projsemaforo
{
    internal class Semaforo
    {
        private byte estado;

        public Semaforo()
        {
            this.estado = 0;
            // com rua1 = vd e rua2 = vm - situação inicial
        }

        public void setVerde(int rua)
        {
            if(rua == 1)
            {
                this.estado = (byte)((int)this.estado | 1);
            }
            else
                if (rua == 2)
            {
                this.estado = (byte)((int)this.estado | 64);
            }
        }

        public void setAmarelo(int rua)
        {
            if (rua == 1)
            {
                this.estado = (byte)((int)this.estado | 2);
            }
            else
               if (rua == 2)
            {
                this.estado = (byte)((int)this.estado | 128);
            }
        }

        public void setVermelho(int rua)
        {
            if (rua == 1)
            {
                this.estado = (byte)((int)this.estado | 4);
            }
            else
               if (rua == 2)
            {
                this.estado = (byte)((int)this.estado | 254);
            }
        }

        public byte getEstado()
        {
            return this.estado;
        }

        public int getEstado(int rua)
        {
            // 1. Vd - 2. Am - 3. Vm
            byte aux = 0;
            if (estado == 1 || estado == 64)
            {
                aux = 1;
            }
            else
                if(estado==2 || estado == 128)
            {
                aux = 2;
            }
            else
            {
                aux = 3;
            }
            return aux;
        }
    }
}
