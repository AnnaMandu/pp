﻿namespace projsemaforo
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblR1 = new System.Windows.Forms.Label();
            this.lblR2 = new System.Windows.Forms.Label();
            this.txtRua = new System.Windows.Forms.TextBox();
            this.btnVm = new System.Windows.Forms.Button();
            this.btnAm = new System.Windows.Forms.Button();
            this.btnVd = new System.Windows.Forms.Button();
            this.picR1 = new System.Windows.Forms.PictureBox();
            this.picR2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.picR1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picR2)).BeginInit();
            this.SuspendLayout();
            // 
            // lblR1
            // 
            this.lblR1.AutoSize = true;
            this.lblR1.Location = new System.Drawing.Point(145, 82);
            this.lblR1.Name = "lblR1";
            this.lblR1.Size = new System.Drawing.Size(14, 16);
            this.lblR1.TabIndex = 0;
            this.lblR1.Text = "0";
            // 
            // lblR2
            // 
            this.lblR2.AutoSize = true;
            this.lblR2.Location = new System.Drawing.Point(593, 76);
            this.lblR2.Name = "lblR2";
            this.lblR2.Size = new System.Drawing.Size(14, 16);
            this.lblR2.TabIndex = 1;
            this.lblR2.Text = "0";
            // 
            // txtRua
            // 
            this.txtRua.Location = new System.Drawing.Point(294, 76);
            this.txtRua.Name = "txtRua";
            this.txtRua.Size = new System.Drawing.Size(183, 22);
            this.txtRua.TabIndex = 2;
            // 
            // btnVm
            // 
            this.btnVm.Location = new System.Drawing.Point(326, 146);
            this.btnVm.Name = "btnVm";
            this.btnVm.Size = new System.Drawing.Size(136, 51);
            this.btnVm.TabIndex = 3;
            this.btnVm.Text = "Vermelho";
            this.btnVm.UseVisualStyleBackColor = true;
            this.btnVm.Click += new System.EventHandler(this.btnVm_Click);
            // 
            // btnAm
            // 
            this.btnAm.Location = new System.Drawing.Point(326, 233);
            this.btnAm.Name = "btnAm";
            this.btnAm.Size = new System.Drawing.Size(136, 51);
            this.btnAm.TabIndex = 4;
            this.btnAm.Text = "Amarelo";
            this.btnAm.UseVisualStyleBackColor = true;
            this.btnAm.Click += new System.EventHandler(this.btnAm_Click);
            // 
            // btnVd
            // 
            this.btnVd.Location = new System.Drawing.Point(326, 324);
            this.btnVd.Name = "btnVd";
            this.btnVd.Size = new System.Drawing.Size(136, 51);
            this.btnVd.TabIndex = 5;
            this.btnVd.Text = "Verde";
            this.btnVd.UseVisualStyleBackColor = true;
            this.btnVd.Click += new System.EventHandler(this.btnVd_Click);
            // 
            // picR1
            // 
            this.picR1.Image = global::projsemaforo.Properties.Resources.vd;
            this.picR1.Location = new System.Drawing.Point(78, 177);
            this.picR1.Name = "picR1";
            this.picR1.Size = new System.Drawing.Size(178, 140);
            this.picR1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picR1.TabIndex = 6;
            this.picR1.TabStop = false;
            // 
            // picR2
            // 
            this.picR2.Image = global::projsemaforo.Properties.Resources.vm;
            this.picR2.Location = new System.Drawing.Point(510, 177);
            this.picR2.Name = "picR2";
            this.picR2.Size = new System.Drawing.Size(178, 140);
            this.picR2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picR2.TabIndex = 7;
            this.picR2.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(746, 487);
            this.Controls.Add(this.picR2);
            this.Controls.Add(this.picR1);
            this.Controls.Add(this.btnVd);
            this.Controls.Add(this.btnAm);
            this.Controls.Add(this.btnVm);
            this.Controls.Add(this.txtRua);
            this.Controls.Add(this.lblR2);
            this.Controls.Add(this.lblR1);
            this.Name = "Form1";
            this.Text = "Semaforo";
            ((System.ComponentModel.ISupportInitialize)(this.picR1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picR2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblR1;
        private System.Windows.Forms.Label lblR2;
        private System.Windows.Forms.TextBox txtRua;
        private System.Windows.Forms.Button btnVm;
        private System.Windows.Forms.Button btnAm;
        private System.Windows.Forms.Button btnVd;
        private System.Windows.Forms.PictureBox picR1;
        private System.Windows.Forms.PictureBox picR2;
    }
}

