﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LED
{
    public partial class Form : System.Windows.Forms.Form
    {
        private Leds leds;
        public Form()
        {
            InitializeComponent();
            leds = new Leds();
            atualizaInterface();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btn1_Click(object sender, EventArgs e)
        {
            if(leds.getEstado(1))
            {
                leds.apagar(1);
            }
            else
            {
                leds.apagar(1);
            }
            atualizaInterface();
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            if (leds.getEstado(2))
            {
                leds.apagar(2);
            }
            else
            {
                leds.apagar(2);
            }
            atualizaInterface();
        }
        private void btn3_Click(object sender, EventArgs e)
        {
            if (leds.getEstado(3))
            {
                leds.apagar(3);
            }
            else
            {
                leds.apagar(3);
            }
            atualizaInterface();
        }
        private void btn4_Click(object sender, EventArgs e)
        {
            if (leds.getEstado(4))
            {
                leds.apagar(4);
            }
            else
            {
                leds.apagar(4);
            }
            atualizaInterface();
        }

        private void btn5_Click(object sender, EventArgs e)
        {
            if (leds.getEstado(5))
            {
                leds.apagar(5);
            }
            else
            {
                leds.apagar(5);
            }
            atualizaInterface();
        }

        private void btn6_Click(object sender, EventArgs e)
        {
            if (leds.getEstado(6))
            {
                leds.apagar(6);
            }
            else
            {
                leds.apagar(6);
            }
            atualizaInterface();
        }

        private void btn7_Click(object sender, EventArgs e)
        {
            if (leds.getEstado(7))
            {
                leds.apagar(7);
            }
            else
            {
                leds.apagar(7);
            }
            atualizaInterface();
        }

        private void btn8_Click(object sender, EventArgs e)
        {
            if (leds.getEstado(8))
            {
                leds.apagar(8);
            }
            else
            {
                leds.apagar(8);
            }
            atualizaInterface();
        }
        private void atualizaInterface()
        {
            pic1.Image =
                            (leds.getEstado(1) ?
                            LED.Properties.Resources.lam_aceso :
                            LED.Properties.Resources.lamp_apagado);
            btn1.Text = (leds.getEstado(1) ? "Off" : "On");

            pic2.Image =
                           (leds.getEstado(2) ?
                           LED.Properties.Resources.lam_aceso :
                           LED.Properties.Resources.lamp_apagado);
            btn2.Text = (leds.getEstado(2) ? "Off" : "On");

            pic3.Image =
                           (leds.getEstado(3) ?
                           LED.Properties.Resources.lam_aceso :
                           LED.Properties.Resources.lamp_apagado);

            btn3.Text = (leds.getEstado(3) ? "Off" : "On");

            pic4.Image =
                           (leds.getEstado(4) ?
                           LED.Properties.Resources.lam_aceso :
                           LED.Properties.Resources.lamp_apagado);
            btn4.Text = (leds.getEstado(4) ? "Off" : "On");

            pic5.Image =
                           (leds.getEstado(5) ?
                           LED.Properties.Resources.lam_aceso :
                           LED.Properties.Resources.lamp_apagado);
            btn5.Text = (leds.getEstado(5) ? "Off" : "On");

            pic6.Image =
                           (leds.getEstado(6) ?
                           LED.Properties.Resources.lam_aceso :
                           LED.Properties.Resources.lamp_apagado);
            btn6.Text = (leds.getEstado(6) ? "Off" : "On");

            pic7.Image =
                           (leds.getEstado(7) ?
                           LED.Properties.Resources.lam_aceso :
                           LED.Properties.Resources.lamp_apagado);
            btn7.Text = (leds.getEstado(7) ? "Off" : "On");

            pic8.Image =
                           (leds.getEstado(8) ?
                           LED.Properties.Resources.lam_aceso :
                           LED.Properties.Resources.lamp_apagado);
            btn8.Text = (leds.getEstado(8) ? "Off" : "On");
        }
    }
}
